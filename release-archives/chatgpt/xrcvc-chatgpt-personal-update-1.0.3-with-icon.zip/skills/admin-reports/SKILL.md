---
name: admin-reports
description: Explain XRCVC Library reporting for Admin and Developer roles. Use for report catalogs, report summaries, tables, and date-bounded operational analysis; do not use for Staff reporting or raw transaction lookup.
---

# Explain Admin and Developer Reports

Reports are server-authorized for Admin and Developer roles only. Start with `/auth/me` through `get_api_output_as_markdown`; Staff and Member users must not be offered report paths.

## MCP output format

- Use `get_api_output_as_markdown` for `/reports`, `/reports/{reportId}`, `/reports/{reportId}/tables/{tableId}`, and `/reports/combined`.
- Request `/reports` first when the report ID is unknown; use its returned report/table IDs rather than guessing them.
- Use supported `start_date` and `end_date` query values when the requested reporting period differs from the server default. Dates cannot precede `2026-01-01`.
- Markdown report results are complete within their documented report/table bounds. Do not claim a JSON page or cursor is complete Markdown evidence.
- For a requested order, pass `sort_by=<table schema column key>&sort_order=asc|desc` to `/reports/{reportId}`, `/reports/{reportId}/tables/{tableId}`, or `/reports/combined`. Use a key returned in that table's `schema`; the combined endpoint sorts each table containing that key. Keep the same sort parameters on every JSON continuation request. Markdown table output remains complete.

## Catalog Taxonomy Breakdown

- Use `/reports/catalog-taxonomy` for current counts by taxonomy value. Its eight tables cover Book Categories, Formats, and Keywords; Teaching Learning Aid Subjects and Topics; and Tactile Diagram Subjects, Topics, and Diagram Types. For example, `/reports/catalog-taxonomy/tables/book-categories?sort_by=count&sort_order=desc` ranks Book categories by linked-resource count; `sort_by=value&sort_order=asc` sorts their names.
- These are counts of resource-to-taxonomy associations, so one catalog resource can contribute to several values. `count: null` means a stored usage count is unavailable; it is not zero. The report contains aggregate taxonomy values and counts, not individual catalog records.
- This is a current snapshot. Do not imply that `start_date` or `end_date` reconstructs historical taxonomy counts. Do not look for its breakdown inside Catalog Health.

## Date conversion and display

- Treat returned report timestamps that include a time or UTC offset as UTC database instants. Convert them to the user's known local timezone; if that timezone is unavailable or conversion fails, use Indian Standard Time (`Asia/Kolkata`, UTC+05:30).
- Render every converted timestamp as `D MMMM YYYY, h:mm AM/PM` in a 12-hour clock, including the timezone when useful for clarity (for example, `25 August 2026, 9:30 PM IST`). Do not use condensed numeric dates such as `25082026`, and do not return ISO/UTC timestamps unless the user asks for the source value.
- Do not convert date-only report periods or `start_date`/`end_date` filters without a time or offset; format them as `D MMMM YYYY` without inventing a time.

## Workflow

1. Confirm the role and select the report catalog, one report, a named table, or the combined report based on the question.
2. State the requested/default time range before interpreting totals, trends, or comparisons.
3. Preserve report/table names, metric labels, units, and source links. Clearly distinguish observed values from an inference.
4. For a transaction-level follow-up, use the Admin Transactions skill rather than treating report aggregates as record detail.
5. For a requested report-default change, hand off to XRCVC Settings Management. For report-data deletion or rebuild, hand off to Admin Maintenance; do not treat those state-changing operations as report reads.

## Catalog Health open-cart impact

- For members whose open carts contain catalog items that are currently unable to be requested, use `/reports/catalog-health/tables/open-cart-unrequestable-by-member`. This table groups blocked items under the returned `memberDisplayName`, `memberName`, and `membershipId`.
- For the inverse view, use `/reports/catalog-health/tables/open-cart-unrequestable-by-item`. This table groups affected members under each catalog item and returns the exact current member count, request-block reason, and the catalog item's updater identity/date.
- These two tables are current point-in-time Catalog Health data. State that scope explicitly; do not imply that `start_date` or `end_date` reconstructs historical cart membership.
- Preserve each returned catalog item's reason and audit fields. When listing members, render the row's paired name and Membership ID as `Full Name (Membership ID)` and do not make a separate directory lookup.

## Response rules

- Whenever an administrative report result contains a Membership ID, present that exact row's corresponding returned full name as `Full Name (Membership ID)`. Use the matching `fullName`, `memberName`, or other explicitly paired name field from that same row; never output the Membership ID alone when its name is returned. If no matching name is returned, write `Full name unavailable (Membership ID)` instead of guessing or making an unrelated directory lookup.
- Do not retrieve or summarize reports for Staff or Member roles; report the server-enforced role boundary.
- Identify filters and dates behind every conclusion, and avoid causal claims that the report does not establish.
- Treat an unavailable report, not found report/table, and access denial as different outcomes.
